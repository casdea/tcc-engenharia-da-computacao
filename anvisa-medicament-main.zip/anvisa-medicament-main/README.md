### API de consumo da base de dados de medicamentos da Anvisa
**Desenvolvedor: Amaury Conde y Martin Neto**<br/>

Data da versão da planilha de dados: 15/05/2018<br/>
Panilha (formato xls) disponível em: http://portal.anvisa.gov.br/listas-de-precos
- - - -
#### Versões<br/>
- 1.0.0<br/>
      Primeira versão da API de acesso a base de dados da Anvisa<br/>
